#ifndef DOTANDBOX_WINDOW_H
#define DOTANDBOX_WINDOW_H

#include <QMainWindow>
#include <map.H>
#include <player.H>

namespace Ui {
class dotandbox_window;
}

class dotandbox_window : public QMainWindow
{
    Q_OBJECT

public:
    explicit dotandbox_window(QWidget *parent = 0);
    ~dotandbox_window();
    void refresh();

    player p1, p2;


private slots:
    void on_line0010_clicked();

    void on_line0001_clicked();

    void on_line1011_clicked();

    void on_line0111_clicked();

    void on_line1020_clicked();

    void on_line2021_clicked();

    void on_line1121_clicked();

    void on_line0102_clicked();

    void on_line0212_clicked();

    void on_line1112_clicked();

    void on_line1222_clicked();

    void on_line2122_clicked();

private:
    Ui::dotandbox_window *ui;
    map<3,3> _map;
    MOVE cur_mv;
    uint p1_last_score = 0;
    uint p2_last_score = 0;
    int turno = 0;

};

#endif // DOTANDBOX_WINDOW_H
