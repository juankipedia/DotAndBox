#ifndef GAME_WINDOW_H
#define GAME_WINDOW_H

#include <QDialog>
#include <dot.H>
#include <map.H>
#include <player.H>

namespace Ui {
class game_window;
}

class game_window : public QDialog
{
    Q_OBJECT

public:
    explicit game_window(QWidget *parent = 0);

    void start_game();
    bool make_move(QMouseEvent *move);
    ~game_window();
    player p1, p2;
    map<3,3> *m_game;

private slots:


private:
    Ui::game_window *ui;
};

#endif // GAME_WINDOW_H
