#include "dotandbox_window.h"
#include "ui_dotandbox_window.h"

dotandbox_window::dotandbox_window(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::dotandbox_window)
{
    ui->setupUi(this);
    ui->label_player1->setStyleSheet("QLabel { color : #FF4F00; }");
    ui->label_scorep1->setStyleSheet("QLabel { color : #FF4F00; }");
    ui->label_scorep1->setText(QString::number(_map.get_p1_score()));
    ui->label_player2->setStyleSheet("QLabel { color : #216126; }");
    ui->label_scorep2->setStyleSheet("QLabel { color : #216126; }");
    ui->label_scorep2->setText(QString::number(_map.get_p2_score()));
}

dotandbox_window::~dotandbox_window()
{
    delete ui;
}

void dotandbox_window::refresh(){
    //Player 1:
    this->ui->label_player1->setText(QString::fromStdString(p1.get_id()));
    //Player 2:
    this->ui->label_player2->setText(QString::fromStdString(p2.get_id()));
}

void dotandbox_window::on_line0010_clicked()
{
    if(turno==0)
    {
      ui->line0010->setStyleSheet("background-color:#FF4F00;");
      p1_last_score = _map.get_p1_score();
      std::get<0>(std::get<0>(cur_mv)) = 0;
      std::get<1>(std::get<0>(cur_mv)) = 0;

      std::get<0>(std::get<1>(cur_mv)) = 1;
      std::get<1>(std::get<1>(cur_mv)) = 0;

      _map.play(cur_mv,1);

      if(p1_last_score == _map.get_p1_score())
      {
          turno = 1;
      }
    }
    else
    {
        ui->line0010->setStyleSheet("background-color:#216126;");
        p2_last_score = _map.get_p2_score();
        std::get<0>(std::get<0>(cur_mv)) = 0;
        std::get<1>(std::get<0>(cur_mv)) = 0;

        std::get<0>(std::get<1>(cur_mv)) = 1;
        std::get<1>(std::get<1>(cur_mv)) = 0;

        _map.play(cur_mv,2);

        if(p2_last_score == _map.get_p2_score())
        {
            turno = 0;
        }
    }
    ui->label_scorep1->setText(QString::number(_map.get_p1_score()));
    ui->label_scorep2->setText(QString::number(_map.get_p2_score()));

}

void dotandbox_window::on_line0001_clicked()
{
    if(turno==0)
    {
      ui->line0001->setStyleSheet("background-color:#FF4F00;");
      p1_last_score = _map.get_p1_score();
      std::get<0>(std::get<0>(cur_mv)) = 0;
      std::get<1>(std::get<0>(cur_mv)) = 0;

      std::get<0>(std::get<1>(cur_mv)) = 0;
      std::get<1>(std::get<1>(cur_mv)) = 1;

      _map.play(cur_mv,1);

      if(p1_last_score == _map.get_p1_score())
      {
          turno = 1;
      }
    }
    else
    {
        ui->line0001->setStyleSheet("background-color:#216126;");
        p2_last_score = _map.get_p2_score();
        std::get<0>(std::get<0>(cur_mv)) = 0;
        std::get<1>(std::get<0>(cur_mv)) = 0;

        std::get<0>(std::get<1>(cur_mv)) = 0;
        std::get<1>(std::get<1>(cur_mv)) = 1;

        _map.play(cur_mv,2);

        if(p2_last_score == _map.get_p2_score())
        {
            turno = 0;
        }
    }
    ui->label_scorep1->setText(QString::number(_map.get_p1_score()));
    ui->label_scorep2->setText(QString::number(_map.get_p2_score()));
}

void dotandbox_window::on_line1011_clicked()
{
    if(turno==0)
    {
      ui->line1011->setStyleSheet("background-color:#FF4F00;");
      p1_last_score = _map.get_p1_score();
      std::get<0>(std::get<0>(cur_mv)) = 1;
      std::get<1>(std::get<0>(cur_mv)) = 0;

      std::get<0>(std::get<1>(cur_mv)) = 1;
      std::get<1>(std::get<1>(cur_mv)) = 1;

      _map.play(cur_mv,1);

      if(p1_last_score == _map.get_p1_score())
      {
          turno = 1;
      }
    }
    else
    {
        ui->line1011->setStyleSheet("background-color:#216126;");
        p2_last_score = _map.get_p2_score();
        std::get<0>(std::get<0>(cur_mv)) = 1;
        std::get<1>(std::get<0>(cur_mv)) = 0;

        std::get<0>(std::get<1>(cur_mv)) = 1;
        std::get<1>(std::get<1>(cur_mv)) = 1;

        _map.play(cur_mv,2);

        if(p2_last_score == _map.get_p2_score())
        {
            turno = 0;
        }
    }
    ui->label_scorep1->setText(QString::number(_map.get_p1_score()));
    ui->label_scorep2->setText(QString::number(_map.get_p2_score()));
}

void dotandbox_window::on_line0111_clicked()
{
    if(turno==0)
    {
      ui->line0111->setStyleSheet("background-color:#FF4F00;");
      p1_last_score = _map.get_p1_score();
      std::get<0>(std::get<0>(cur_mv)) = 0;
      std::get<1>(std::get<0>(cur_mv)) = 1;

      std::get<0>(std::get<1>(cur_mv)) = 1;
      std::get<1>(std::get<1>(cur_mv)) = 1;

      _map.play(cur_mv,1);

      if(p1_last_score == _map.get_p1_score())
      {
          turno = 1;
      }
    }
    else
    {
        ui->line0111->setStyleSheet("background-color:#216126;");
        p2_last_score = _map.get_p2_score();
        std::get<0>(std::get<0>(cur_mv)) = 0;
        std::get<1>(std::get<0>(cur_mv)) = 1;

        std::get<0>(std::get<1>(cur_mv)) = 1;
        std::get<1>(std::get<1>(cur_mv)) = 1;

        _map.play(cur_mv,2);

        if(p2_last_score == _map.get_p2_score())
        {
            turno = 0;
        }
    }
    ui->label_scorep1->setText(QString::number(_map.get_p1_score()));
    ui->label_scorep2->setText(QString::number(_map.get_p2_score()));
}

void dotandbox_window::on_line1020_clicked()
{
    if(turno==0)
    {
      ui->line1020->setStyleSheet("background-color:#FF4F00;");
      p1_last_score = _map.get_p1_score();
      std::get<0>(std::get<0>(cur_mv)) = 1;
      std::get<1>(std::get<0>(cur_mv)) = 0;

      std::get<0>(std::get<1>(cur_mv)) = 2;
      std::get<1>(std::get<1>(cur_mv)) = 0;

      _map.play(cur_mv,1);

      if(p1_last_score == _map.get_p1_score())
      {
          turno = 1;
      }
    }
    else
    {
        ui->line1020->setStyleSheet("background-color:#216126;");
        p2_last_score = _map.get_p2_score();
        std::get<0>(std::get<0>(cur_mv)) = 1;
        std::get<1>(std::get<0>(cur_mv)) = 0;

        std::get<0>(std::get<1>(cur_mv)) = 2;
        std::get<1>(std::get<1>(cur_mv)) = 0;

        _map.play(cur_mv,2);

        if(p2_last_score == _map.get_p2_score())
        {
            turno = 0;
        }
    }
    ui->label_scorep1->setText(QString::number(_map.get_p1_score()));
    ui->label_scorep2->setText(QString::number(_map.get_p2_score()));
}

void dotandbox_window::on_line2021_clicked()
{
    if(turno==0)
    {
      ui->line2021->setStyleSheet("background-color:#FF4F00;");
      p1_last_score = _map.get_p1_score();
      std::get<0>(std::get<0>(cur_mv)) = 2;
      std::get<1>(std::get<0>(cur_mv)) = 0;

      std::get<0>(std::get<1>(cur_mv)) = 2;
      std::get<1>(std::get<1>(cur_mv)) = 1;

      _map.play(cur_mv,1);

      if(p1_last_score == _map.get_p1_score())
      {
          turno = 1;
      }
    }
    else
    {
        ui->line2021->setStyleSheet("background-color:#216126;");
        p2_last_score = _map.get_p2_score();
        std::get<0>(std::get<0>(cur_mv)) = 2;
        std::get<1>(std::get<0>(cur_mv)) = 0;

        std::get<0>(std::get<1>(cur_mv)) = 2;
        std::get<1>(std::get<1>(cur_mv)) = 1;

        _map.play(cur_mv,2);

        if(p2_last_score == _map.get_p2_score())
        {
            turno = 0;
        }
    }
    ui->label_scorep1->setText(QString::number(_map.get_p1_score()));
    ui->label_scorep2->setText(QString::number(_map.get_p2_score()));
}

void dotandbox_window::on_line1121_clicked()
{
    if(turno==0)
    {
      ui->line1121->setStyleSheet("background-color:#FF4F00;");
      p1_last_score = _map.get_p1_score();
      std::get<0>(std::get<0>(cur_mv)) = 1;
      std::get<1>(std::get<0>(cur_mv)) = 1;

      std::get<0>(std::get<1>(cur_mv)) = 2;
      std::get<1>(std::get<1>(cur_mv)) = 1;

      _map.play(cur_mv,1);

      if(p1_last_score == _map.get_p1_score())
      {
          turno = 1;
      }
    }
    else
    {
        ui->line1121->setStyleSheet("background-color:#216126;");
        p2_last_score = _map.get_p2_score();
        std::get<0>(std::get<0>(cur_mv)) = 1;
        std::get<1>(std::get<0>(cur_mv)) = 1;

        std::get<0>(std::get<1>(cur_mv)) = 2;
        std::get<1>(std::get<1>(cur_mv)) = 1;

        _map.play(cur_mv,2);

        if(p2_last_score == _map.get_p2_score())
        {
            turno = 0;
        }
    }
    ui->label_scorep1->setText(QString::number(_map.get_p1_score()));
    ui->label_scorep2->setText(QString::number(_map.get_p2_score()));
}

void dotandbox_window::on_line0102_clicked()
{
    if(turno==0)
    {
      ui->line0102->setStyleSheet("background-color:#FF4F00;");
      p1_last_score = _map.get_p1_score();
      std::get<0>(std::get<0>(cur_mv)) = 0;
      std::get<1>(std::get<0>(cur_mv)) = 1;

      std::get<0>(std::get<1>(cur_mv)) = 0;
      std::get<1>(std::get<1>(cur_mv)) = 2;

      _map.play(cur_mv,1);

      if(p1_last_score == _map.get_p1_score())
      {
          turno = 1;
      }
    }
    else
    {
        ui->line0102->setStyleSheet("background-color:#216126;");
        p2_last_score = _map.get_p2_score();
        std::get<0>(std::get<0>(cur_mv)) = 0;
        std::get<1>(std::get<0>(cur_mv)) = 1;

        std::get<0>(std::get<1>(cur_mv)) = 0;
        std::get<1>(std::get<1>(cur_mv)) = 2;

        _map.play(cur_mv,2);

        if(p2_last_score == _map.get_p2_score())
        {
            turno = 0;
        }
    }
    ui->label_scorep1->setText(QString::number(_map.get_p1_score()));
    ui->label_scorep2->setText(QString::number(_map.get_p2_score()));
}

void dotandbox_window::on_line0212_clicked()
{
    if(turno==0)
    {
      ui->line0212->setStyleSheet("background-color:#FF4F00;");
      p1_last_score = _map.get_p1_score();
      std::get<0>(std::get<0>(cur_mv)) = 0;
      std::get<1>(std::get<0>(cur_mv)) = 2;

      std::get<0>(std::get<1>(cur_mv)) = 1;
      std::get<1>(std::get<1>(cur_mv)) = 2;

      _map.play(cur_mv,1);

      if(p1_last_score == _map.get_p1_score())
      {
          turno = 1;
      }
    }
    else
    {
        ui->line0212->setStyleSheet("background-color:#216126;");
        p2_last_score = _map.get_p2_score();
        std::get<0>(std::get<0>(cur_mv)) = 0;
        std::get<1>(std::get<0>(cur_mv)) = 2;

        std::get<0>(std::get<1>(cur_mv)) = 1;
        std::get<1>(std::get<1>(cur_mv)) = 2;

        _map.play(cur_mv,2);

        if(p2_last_score == _map.get_p2_score())
        {
            turno = 0;
        }
    }
    ui->label_scorep1->setText(QString::number(_map.get_p1_score()));
    ui->label_scorep2->setText(QString::number(_map.get_p2_score()));
}

void dotandbox_window::on_line1112_clicked()
{
    if(turno==0)
    {
      ui->line1112->setStyleSheet("background-color:#FF4F00;");
      p1_last_score = _map.get_p1_score();
      std::get<0>(std::get<0>(cur_mv)) = 1;
      std::get<1>(std::get<0>(cur_mv)) = 1;

      std::get<0>(std::get<1>(cur_mv)) = 1;
      std::get<1>(std::get<1>(cur_mv)) = 2;

      _map.play(cur_mv,1);

      if(p1_last_score == _map.get_p1_score())
      {
          turno = 1;
      }
    }
    else
    {
        ui->line1112->setStyleSheet("background-color:#216126;");
        p2_last_score = _map.get_p2_score();
        std::get<0>(std::get<0>(cur_mv)) = 1;
        std::get<1>(std::get<0>(cur_mv)) = 1;

        std::get<0>(std::get<1>(cur_mv)) = 1;
        std::get<1>(std::get<1>(cur_mv)) = 2;

        _map.play(cur_mv,2);

        if(p2_last_score == _map.get_p2_score())
        {
            turno = 0;
        }
    }
    ui->label_scorep1->setText(QString::number(_map.get_p1_score()));
    ui->label_scorep2->setText(QString::number(_map.get_p2_score()));
}

void dotandbox_window::on_line1222_clicked()
{
    if(turno==0)
    {
      ui->line1222->setStyleSheet("background-color:#FF4F00;");
      p1_last_score = _map.get_p1_score();
      std::get<0>(std::get<0>(cur_mv)) = 1;
      std::get<1>(std::get<0>(cur_mv)) = 2;

      std::get<0>(std::get<1>(cur_mv)) = 2;
      std::get<1>(std::get<1>(cur_mv)) = 2;

      _map.play(cur_mv,1);

      if(p1_last_score == _map.get_p1_score())
      {
          turno = 1;
      }
    }
    else
    {
        ui->line1222->setStyleSheet("background-color:#216126;");
        p2_last_score = _map.get_p2_score();
        std::get<0>(std::get<0>(cur_mv)) = 1;
        std::get<1>(std::get<0>(cur_mv)) = 2;

        std::get<0>(std::get<1>(cur_mv)) = 2;
        std::get<1>(std::get<1>(cur_mv)) = 2;

        _map.play(cur_mv,2);

        if(p2_last_score == _map.get_p2_score())
        {
            turno = 0;
        }
    }
    ui->label_scorep1->setText(QString::number(_map.get_p1_score()));
    ui->label_scorep2->setText(QString::number(_map.get_p2_score()));

}

void dotandbox_window::on_line2122_clicked()
{
    if(turno==0)
    {
      ui->line2122->setStyleSheet("background-color:#FF4F00;");
      p1_last_score = _map.get_p1_score();
      std::get<0>(std::get<0>(cur_mv)) = 2;
      std::get<1>(std::get<0>(cur_mv)) = 1;

      std::get<0>(std::get<1>(cur_mv)) = 2;
      std::get<1>(std::get<1>(cur_mv)) = 2;

      _map.play(cur_mv,1);

      if(p1_last_score == _map.get_p1_score())
      {
          turno = 1;
      }
    }
    else
    {
        ui->line2122->setStyleSheet("background-color:#216126;");
        p2_last_score = _map.get_p2_score();
        std::get<0>(std::get<0>(cur_mv)) = 2;
        std::get<1>(std::get<0>(cur_mv)) = 1;

        std::get<0>(std::get<1>(cur_mv)) = 2;
        std::get<1>(std::get<1>(cur_mv)) = 2;

        _map.play(cur_mv,2);

        if(p2_last_score == _map.get_p2_score())
        {
            turno = 0;
        }
    }
    ui->label_scorep1->setText(QString::number(_map.get_p1_score()));
    ui->label_scorep2->setText(QString::number(_map.get_p2_score()));
}
