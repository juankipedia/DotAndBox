#include "game_window.h"
#include "ui_game_window.h"

game_window::game_window(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::game_window)
{
    ui->setupUi(this);
}

game_window::~game_window()
{
    delete ui;
}

void game_window::start_game(){
    //Player 1:
    this->ui->l_p1_id->setText(QString::fromStdString(this->p1.get_id()));
    this->ui->l_p1_score->setText(QString::number(this->p1.get_record()));
    //Player 2:
    this->ui->l_p2_id->setText(QString::fromStdString(this->p2.get_id()));
    this->ui->l_p2_score->setText(QString::number(this->p2.get_record()));

    //////////////_______
    //Adding dots:
    QRectF rect_for_ellipse(0,30,20,20);
    QColor e_color("navy");
    QColor e_color2("magenta");
    QBrush e_brush(e_color,Qt::SolidPattern);
    QBrush e_brush2(e_color2,Qt::SolidPattern);

    QGraphicsEllipseItem *dot_00, *dot_01, *dot_02, *dot_10, *dot_11, *dot_12
            , *dot_20, *dot_21, *dot_22;

    QGraphicsScene *scene = new QGraphicsScene(0,0,0,0);
    this->ui->g_map->setScene(scene);

    dot_00 = new QGraphicsEllipseItem(rect_for_ellipse,e_color2,e_brush);
    dot_01 = new QGraphicsEllipseItem(0,130,20,20,e_color2,e_brush);
    dot_02 = new QGraphicsEllipseItem(0,230,20,20,e_color2,e_brush);

    dot_10 = new QGraphicsEllipseItem(100,30,20,20,e_color2,e_brush);
    dot_11 = new QGraphicsEllipseItem(100,130,20,20,e_color2,e_brush);
    dot_12 = new QGraphicsEllipseItem(100,230,20,20,e_color2,e_brush);

    dot_20 = new QGraphicsEllipseItem(200,30,20,20,e_color2,e_brush);
    dot_21 = new QGraphicsEllipseItem(200,130,20,20,e_color2,e_brush);
    dot_22 = new QGraphicsEllipseItem(200,230,20,20,e_color2,e_brush);

    scene->addEllipse(rect_for_ellipse,e_color2,e_brush);
    scene->addEllipse(0,130,20,20,e_color2,e_brush);
    scene->addEllipse(0,230,20,20,e_color2,e_brush);

    scene->addEllipse(100,30,20,20,e_color2,e_brush);
    scene->addEllipse(100,130,20,20,e_color2,e_brush);
    scene->addEllipse(100,230,20,20,e_color2,e_brush);

    scene->addEllipse(200,30,20,20,e_color2,e_brush);
    scene->addEllipse(200,130,20,20,e_color2,e_brush);
    scene->addEllipse(200,230,20,20,e_color2,e_brush);



    //this->ui->g_map->show();
}

void game_window::make_move(QMouseEvent *move){
    if(move->button() == Qt::LeftButton){
        if(move->pos().x() >= -10 and move->pos().x() <= 10 and move->pos().y() >= 120 and move->pos().y() <= 140){

        }
    }




}
